package com.project.tastyfood.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.project.tastyfood.R;

public class LoginActivity extends AppCompatActivity {
    private EditText edUsername;
    private EditText edPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edUsername = findViewById(R.id.ed_username);
        edPassword = findViewById(R.id.ed_password);
        btnLogin = findViewById(R.id.btn_login);

        setListeners();
    }

    private void setListeners() {
        btnLogin.setOnClickListener(v -> {
            if (isValid()) {
                String username = edUsername.getText().toString();
                String password = edPassword.getText().toString();

                if (username.equals("TekomD") && password.equals("UNM123")) {
                    startActivity(new Intent(this, MainActivity.class));
                } else {
                    Toast.makeText(this, "Username dan Password salah!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValid() {
        if (edUsername.getText().toString().isEmpty()) {
            Toast.makeText(this, "Username tidak boleh kosong!", Toast.LENGTH_SHORT).show();
            return false;
        } else if (edPassword.getText().toString().isEmpty()) {
            Toast.makeText(this, "Password tidak boleh kosong!", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }
}